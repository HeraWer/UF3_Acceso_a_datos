package mongomaven;

public class Consolas {

}
