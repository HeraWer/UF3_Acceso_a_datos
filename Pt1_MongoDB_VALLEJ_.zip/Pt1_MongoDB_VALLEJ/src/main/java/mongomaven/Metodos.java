package mongomaven;

public class Metodos {

}
